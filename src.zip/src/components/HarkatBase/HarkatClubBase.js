import React from 'react'

const HarkatClubBase = () => {
  return (
    <div>HarkatClubBase</div>
  )
}

export default HarkatClubBase