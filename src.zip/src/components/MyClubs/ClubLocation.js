import React from 'react'
import clubImg from "../../assets/club.png"
const ClubLocation = () => {
  return (
    <div className='w-[100%] h-[100vh] border border-red-700'>
        <img src={clubImg} alt="img"/>
    </div>
  )
}

export default ClubLocation