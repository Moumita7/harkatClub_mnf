import React from 'react';

const MyclubLoading = () => {
   
    return (
        <div className='flex-column justify-center items-center text-center mt-20'>
           
             
           
        </div>
    );
};

export default MyclubLoading;