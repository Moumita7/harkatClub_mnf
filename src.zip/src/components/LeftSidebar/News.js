import React from 'react';

const News = () => {
    return (
        <div>
            <h1>News</h1>
        </div>
    );
};

export default News;