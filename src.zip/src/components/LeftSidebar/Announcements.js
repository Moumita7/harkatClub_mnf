import React from 'react';

const Announcements = () => {
    return (
        <div>
            <h1>Annoucements</h1>
        </div>
    );
};

export default Announcements;