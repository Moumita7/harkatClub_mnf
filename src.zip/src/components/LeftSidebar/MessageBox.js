import React from 'react';

const MessageBox = () => {
    return (
        <div>
            <h1>Message Box</h1>
        </div>
    );
};

export default MessageBox;    

