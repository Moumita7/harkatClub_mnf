import React from 'react';

const ProposeActivity = () => {
    return (
        <div>
            <h1>Propose an Activity</h1>
        </div>
    );
};

export default ProposeActivity;