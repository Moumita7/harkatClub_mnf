import React from 'react';

const FutureActivity = () => {
    return (
        <div>
            <h1>Future Activity</h1>
        </div>
    );
};

export default FutureActivity;