import React from 'react';

const PromoteClub = () => {
    return (
        <div>
            <h1>Promote Club</h1>
        </div>
    );
};

export default PromoteClub;