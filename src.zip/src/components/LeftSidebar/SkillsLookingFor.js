import React from 'react';

const SkillsLookingFor = () => {
    return (
        <div>
            <h1>Skill Looking For</h1>
        </div>
    );
};

export default SkillsLookingFor;