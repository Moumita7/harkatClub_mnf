import React from 'react';

const CurrentActivities = () => {
    return (
        <div>
            <h1>Current Activities</h1>
        </div>
    );
};

export default CurrentActivities;