import React from 'react';

const PostActivities = () => {
    return (
        <div>
            <h1>Post Activites</h1>
        </div>
    );
};

export default PostActivities;